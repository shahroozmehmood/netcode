﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class IssueLocker
    {
        public int Id { get; set; }
        public int LockerId { get; set; }
        public int MemberId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        
        public virtual Locker Locker { get; set; } = null!;
        public virtual Member Member { get; set; } = null!;
    }
}
