﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class Locker
    {
        public Locker()
        {
            IssueLockers = new HashSet<IssueLocker>();
        }

        public int Id { get; set; }
        public string Number { get; set; } = null!;
        public string Status { get; set; } = null!;
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        
        public virtual ICollection<IssueLocker> IssueLockers { get; set; }
    }
}
