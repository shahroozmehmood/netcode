﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class Member
    {
     

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string FatherHusbandName { get; set; } = null!;
        public string MemberNo { get; set; } = null!;
        public DateTime RegisterAt { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Cnic { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string ContactNo { get; set; } = null!;
        public bool Gender { get; set; }
        public string Height { get; set; } = null!;
        public string Weight { get; set; } = null!;
        public string? VehicleNumber { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        
        public virtual ICollection<Invoice> Invoices { get; set; }
        public virtual ICollection<IssueLocker> IssueLockers { get; set; }
        public virtual ICollection<Subscription> Subscriptions { get; set; }
    }
}
