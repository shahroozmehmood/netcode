﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class Notification
    {
      
        public int Id { get; set; }
        public string Content { get; set; } = null!;
        public int Type { get; set; }
        public DateTime CreatedAt { get; set; }

        public virtual ICollection<NotificationsRead> NotificationsReads { get; set; }
    }
}
