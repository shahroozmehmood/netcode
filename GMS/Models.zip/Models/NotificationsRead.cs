﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class NotificationsRead
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int NotificationId { get; set; }
        public DateTime CreatedAt { get; set; }

        public virtual Notification Notification { get; set; } = null!;
        public virtual User User { get; set; } = null!;
    }
}
