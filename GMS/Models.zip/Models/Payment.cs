﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class Payment
    {
        public int Id { get; set; }
        public int SubscriptionId { get; set; }
        public int PaymentType { get; set; }
        public int? DiscountType { get; set; }
        public decimal? PercentageValue { get; set; }
        public decimal TotalDiscount { get; set; }
        public decimal DiscountedAmount { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        
        public virtual Subscription Subscription { get; set; } = null!;
    }
}
