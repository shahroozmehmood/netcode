﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class Stock
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        
        public int StockSubCategoryId { get; set; }
        public decimal UnitSalePrice { get; set; }
        public decimal UnitPurchasePrice { get; set; }
        public int ThresholdValue { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        
        
        public virtual StockSubCategory StockSubCategory { get; set; } = null!;
    }
}
