﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class StockSubCategory
    {
       

        public int Id { get; set; }
        public int StockCategoryId { get; set; }
        public string Name { get; set; } = null!;
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        
        public virtual StockCategory StockCategory { get; set; } = null!;
        public virtual ICollection<Stock> Stocks { get; set; }
    }
}
