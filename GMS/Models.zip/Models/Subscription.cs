﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class Subscription
    {
      
        public int Id { get; set; }
        public int MemberId { get; set; }
        public int SubscriptionPlanId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        
        public virtual Member Member { get; set; } = null!;
        public virtual SubscriptionPlan SubscriptionPlan { get; set; } = null!;
        public virtual ICollection<Payment> Payments { get; set; }
    }
}
