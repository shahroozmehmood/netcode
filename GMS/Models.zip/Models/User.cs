﻿using System;
using System.Collections.Generic;

namespace GMS.Models
{
    public partial class User
    {
     
        public int Id { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public bool Gender { get; set; }
        public string Password { get; set; } = null!;
        public string Token { get; set; } = null!;
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyAt { get; set; }

        public virtual ICollection<Invoice> Invoices { get; set; }
        public virtual ICollection<IssueLocker> IssueLockers { get; set; }
        public virtual ICollection<Locker> Lockers { get; set; }
        public virtual ICollection<Member> Members { get; set; }
        public virtual ICollection<NotificationsRead> NotificationsReads { get; set; }
        public virtual ICollection<Payment> Payments { get; set; }
        public virtual ICollection<StockCategory> StockCategories { get; set; }
        public virtual ICollection<StockSubCategory> StockSubCategories { get; set; }
        public virtual ICollection<Stock> Stocks { get; set; }
        public virtual ICollection<SubscriptionPlan> SubscriptionPlans { get; set; }
        public virtual ICollection<Subscription> Subscriptions { get; set; }
        public virtual ICollection<UserRole> UserRoles { get; set; }
    }
}
